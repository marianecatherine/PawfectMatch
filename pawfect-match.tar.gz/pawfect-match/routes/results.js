const express = require('express');
const router = express.Router();
const { getRankedMatches } = require('../models/matching');

// Middleware
function isAuthenticated(req, res, next) {
  if (req.session.userId) {
    return next();
  }
  res.redirect('/auth/login');
}

// Results page
router.get('/', isAuthenticated, (req, res) => {
  const userId = req.session.userId;
  const user = global.users.find(u => u.id === userId);
  const response = global.responses.find(r => r.userId === userId);

  if (!response) {
    return res.redirect('/questionnaire');
  }

  const matches = getRankedMatches(response);

  res.render('results', {
    user,
    matches
  });
});

module.exports = router;
