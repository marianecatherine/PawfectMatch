const express = require('express');
const router = express.Router();

// Middleware to check if user is logged in
function isAuthenticated(req, res, next) {
  if (req.session.userId) {
    return next();
  }
  res.redirect('/auth/login');
}

// Home page
router.get('/', (req, res) => {
  res.render('index', {
    user: req.session.userId ? global.users.find(u => u.id === req.session.userId) : null
  });
});

// Browse all pets
router.get('/browse', (req, res) => {
  const availablePets = global.pets.filter(p => p.available);
  res.render('browse', {
    pets: availablePets,
    user: req.session.userId ? global.users.find(u => u.id === req.session.userId) : null
  });
});

// View single pet
router.get('/pet/:id', (req, res) => {
  const pet = global.pets.find(p => p.id === parseInt(req.params.id));
  if (!pet) {
    return res.status(404).send('Pet not found');
  }
  res.render('pet-detail', {
    pet,
    user: req.session.userId ? global.users.find(u => u.id === req.session.userId) : null
  });
});

// Submit adoption request
router.post('/adopt/:petId', isAuthenticated, (req, res) => {
  const petId = parseInt(req.params.petId);
  const userId = req.session.userId;
  
  const pet = global.pets.find(p => p.id === petId);
  if (!pet || !pet.available) {
    return res.status(400).json({ error: 'Pet not available' });
  }

  const request = {
    id: global.adoptionRequests.length + 1,
    userId,
    petId,
    status: 'pending',
    createdAt: new Date(),
    message: req.body.message || ''
  };

  global.adoptionRequests.push(request);
  res.json({ success: true, message: 'Adoption request submitted!' });
});

module.exports = router;
