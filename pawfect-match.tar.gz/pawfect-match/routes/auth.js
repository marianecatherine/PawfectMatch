const express = require('express');
const bcrypt = require('bcrypt');
const router = express.Router();

// Login page
router.get('/login', (req, res) => {
  res.render('login', { error: null });
});

// Login POST
router.post('/login', async (req, res) => {
  const { email, password } = req.body;
  
  const user = global.users.find(u => u.email === email);
  
  if (!user) {
    return res.render('login', { error: 'Invalid email or password' });
  }

  const passwordMatch = await bcrypt.compare(password, user.password);
  
  if (!passwordMatch) {
    return res.render('login', { error: 'Invalid email or password' });
  }

  req.session.userId = user.id;
  req.session.userRole = user.role;
  
  if (user.role === 'admin') {
    res.redirect('/admin/dashboard');
  } else {
    res.redirect('/questionnaire');
  }
});

// Register page
router.get('/register', (req, res) => {
  res.render('register', { error: null });
});

// Register POST
router.post('/register', async (req, res) => {
  const { name, email, password } = req.body;
  
  // Check if user exists
  const existingUser = global.users.find(u => u.email === email);
  if (existingUser) {
    return res.render('register', { error: 'Email already registered' });
  }

  // Hash password
  const hashedPassword = await bcrypt.hash(password, 10);
  
  // Create user
  const newUser = {
    id: global.users.length + 1,
    name,
    email,
    password: hashedPassword,
    role: 'adopter',
    createdAt: new Date()
  };

  global.users.push(newUser);
  
  // Auto-login
  req.session.userId = newUser.id;
  req.session.userRole = newUser.role;
  
  res.redirect('/questionnaire');
});

// Logout
router.get('/logout', (req, res) => {
  req.session.destroy();
  res.redirect('/');
});

module.exports = router;
