const express = require('express');
const router = express.Router();

// Middleware
function isAuthenticated(req, res, next) {
  if (req.session.userId) {
    return next();
  }
  res.redirect('/auth/login');
}

// Questionnaire page
router.get('/', isAuthenticated, (req, res) => {
  const user = global.users.find(u => u.id === req.session.userId);
  const existingResponse = global.responses.find(r => r.userId === req.session.userId);
  
  res.render('questionnaire', {
    user,
    existingResponse: existingResponse || null
  });
});

// Submit questionnaire
router.post('/submit', isAuthenticated, (req, res) => {
  const userId = req.session.userId;
  
  // Remove old response if exists
  global.responses = global.responses.filter(r => r.userId !== userId);
  
  // Save new response
  const response = {
    id: global.responses.length + 1,
    userId,
    residenceType: req.body.residenceType,
    livingSpace: req.body.livingSpace,
    restrictions: req.body.restrictions,
    activityLevel: req.body.activityLevel,
    exerciseCommitment: req.body.exerciseCommitment,
    previousPets: req.body.previousPets,
    trainingExperience: req.body.trainingExperience,
    timeAway: req.body.timeAway,
    household: req.body.household,
    otherPets: req.body.otherPets,
    specialNeedsWilling: req.body.specialNeedsWilling,
    createdAt: new Date()
  };

  global.responses.push(response);
  
  res.redirect('/results');
});

module.exports = router;
