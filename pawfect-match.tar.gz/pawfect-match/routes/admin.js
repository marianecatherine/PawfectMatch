const express = require('express');
const router = express.Router();

// Middleware
function isAdmin(req, res, next) {
  if (req.session.userId && req.session.userRole === 'admin') {
    return next();
  }
  res.redirect('/auth/login');
}

// Admin dashboard
router.get('/dashboard', isAdmin, (req, res) => {
  const user = global.users.find(u => u.id === req.session.userId);
  const stats = {
    totalPets: global.pets.length,
    availablePets: global.pets.filter(p => p.available).length,
    totalUsers: global.users.filter(u => u.role === 'adopter').length,
    pendingRequests: global.adoptionRequests.filter(r => r.status === 'pending').length
  };

  res.render('admin/dashboard', {
    user,
    stats,
    pets: global.pets,
    requests: global.adoptionRequests
  });
});

// Pet management page
router.get('/pets', isAdmin, (req, res) => {
  const user = global.users.find(u => u.id === req.session.userId);
  res.render('admin/pets', {
    user,
    pets: global.pets
  });
});

// Add pet page
router.get('/pets/add', isAdmin, (req, res) => {
  const user = global.users.find(u => u.id === req.session.userId);
  res.render('admin/add-pet', { user });
});

// Add pet POST
router.post('/pets/add', isAdmin, (req, res) => {
  const newPet = {
    id: global.pets.length + 1,
    name: req.body.name,
    species: req.body.species,
    breed: req.body.breed,
    age: parseInt(req.body.age),
    size: req.body.size,
    energyLevel: req.body.energyLevel,
    temperament: req.body.temperament,
    trainingStatus: req.body.trainingStatus,
    housingNeeds: req.body.housingNeeds,
    experienceRequired: req.body.experienceRequired,
    timeRequirement: req.body.timeRequirement,
    specialNeeds: req.body.specialNeeds || 'None',
    goodWithKids: req.body.goodWithKids === 'true',
    goodWithPets: req.body.goodWithPets === 'true',
    description: req.body.description,
    image: req.body.image || 'https://via.placeholder.com/400',
    available: true
  };

  global.pets.push(newPet);
  res.redirect('/admin/pets');
});

// Edit pet page
router.get('/pets/edit/:id', isAdmin, (req, res) => {
  const user = global.users.find(u => u.id === req.session.userId);
  const pet = global.pets.find(p => p.id === parseInt(req.params.id));
  
  if (!pet) {
    return res.status(404).send('Pet not found');
  }

  res.render('admin/edit-pet', { user, pet });
});

// Update pet POST
router.post('/pets/edit/:id', isAdmin, (req, res) => {
  const petId = parseInt(req.params.id);
  const petIndex = global.pets.findIndex(p => p.id === petId);
  
  if (petIndex === -1) {
    return res.status(404).send('Pet not found');
  }

  global.pets[petIndex] = {
    ...global.pets[petIndex],
    name: req.body.name,
    species: req.body.species,
    breed: req.body.breed,
    age: parseInt(req.body.age),
    size: req.body.size,
    energyLevel: req.body.energyLevel,
    temperament: req.body.temperament,
    trainingStatus: req.body.trainingStatus,
    housingNeeds: req.body.housingNeeds,
    experienceRequired: req.body.experienceRequired,
    timeRequirement: req.body.timeRequirement,
    specialNeeds: req.body.specialNeeds || 'None',
    goodWithKids: req.body.goodWithKids === 'true',
    goodWithPets: req.body.goodWithPets === 'true',
    description: req.body.description,
    image: req.body.image,
    available: req.body.available === 'true'
  };

  res.redirect('/admin/pets');
});

// Delete pet
router.post('/pets/delete/:id', isAdmin, (req, res) => {
  const petId = parseInt(req.params.id);
  global.pets = global.pets.filter(p => p.id !== petId);
  res.redirect('/admin/pets');
});

// Adoption requests
router.get('/requests', isAdmin, (req, res) => {
  const user = global.users.find(u => u.id === req.session.userId);
  const requests = global.adoptionRequests.map(r => {
    const adopter = global.users.find(u => u.id === r.userId);
    const pet = global.pets.find(p => p.id === r.petId);
    return { ...r, adopter, pet };
  });

  res.render('admin/requests', {
    user,
    requests
  });
});

// Update request status
router.post('/requests/:id/status', isAdmin, (req, res) => {
  const requestId = parseInt(req.params.id);
  const request = global.adoptionRequests.find(r => r.id === requestId);
  
  if (request) {
    request.status = req.body.status;
    
    // If approved, mark pet as unavailable
    if (req.body.status === 'approved') {
      const pet = global.pets.find(p => p.id === request.petId);
      if (pet) {
        pet.available = false;
      }
    }
  }

  res.redirect('/admin/requests');
});

module.exports = router;
