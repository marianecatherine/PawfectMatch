# 🚀 PawfectMatch MVP - Quick Start Guide

## What You're Getting

A fully functional pet adoption compatibility matching system with:
- ✅ 6 sample pets pre-loaded
- ✅ Working compatibility algorithm
- ✅ Complete user authentication
- ✅ Admin dashboard
- ✅ Responsive design
- ✅ 20 files, ~2000 lines of code

## Installation (5 minutes)

### Step 1: Extract the files
```bash
tar -xzf pawfect-match.tar.gz
cd pawfect-match
```

### Step 2: Install dependencies
```bash
npm install
```

This installs:
- express (web framework)
- ejs (templating)
- bcrypt (password hashing)
- express-session (authentication)
- body-parser (form handling)

### Step 3: Start the server
```bash
npm start
```

You'll see:
```
🐾 PawfectMatch server running on http://localhost:3000

====================================
Welcome to PawfectMatch MVP!
====================================

Test Accounts:
- Adopter: user@example.com / password123
- Admin: admin@example.com / admin123

Features:
✓ Compatibility questionnaire
✓ Algorithmic pet matching
✓ Ranked recommendations
✓ Admin dashboard
✓ Pet management
====================================
```

### Step 4: Open in browser
Navigate to: `http://localhost:3000`

## Testing the System

### As an Adopter (Main Feature Demo)

1. **Register** → Go to /auth/register or use test account
   - Email: user@example.com
   - Password: password123

2. **Complete Questionnaire** → Answer 12 questions about your lifestyle
   - Takes 2-3 minutes
   - Covers housing, activity, experience, time, special needs

3. **View Results** → See 6 pets ranked by compatibility
   - Scores range from 0-100
   - Color-coded: Green (excellent), Blue (good), Orange (fair), Red (poor)
   - Detailed breakdown showing why each pet matches

4. **Request Adoption** → Click on any pet to submit interest

### As an Admin

1. **Login** → Use admin account
   - Email: admin@example.com
   - Password: admin123

2. **View Dashboard** → See system statistics
   - Total pets: 6
   - Available: 6
   - Users: 2
   - Pending requests: varies

3. **Manage Pets** → Add, edit, or delete pets
   - Click "Add New Pet" to test adding
   - Edit any existing pet
   - Delete removes from system

4. **Review Requests** → See adoption interest submissions
   - Mark as approved/pending/rejected

## Key Files to Examine

### Algorithm Logic
`models/matching.js` - The compatibility matching algorithm
- Lines 8-13: Weight definitions (housing 30%, activity 25%, etc.)
- Lines 15-40: Main calculation function
- Lines 42-100: Individual dimension scoring

### Routes
`routes/questionnaire.js` - Handles quiz submission
`routes/results.js` - Generates ranked matches
`routes/admin.js` - Admin functionality

### Views
`views/questionnaire.ejs` - The 12-question form
`views/results.ejs` - Ranked matches display
`views/admin/dashboard.ejs` - Admin panel

## Sample Test Scenarios

### Test Case 1: Perfect Match
**Questionnaire Responses:**
- Housing: House with yard, 1000+ sq ft
- Activity: Very active, daily exercise
- Experience: Currently own pets
- Time: Work from home
- Special: Adults only, no other pets, open to any needs

**Expected Result:** Max (Labrador) should score 90-100

### Test Case 2: Apartment Dweller
**Questionnaire Responses:**
- Housing: Apartment, under 500 sq ft
- Activity: Sedentary
- Experience: Never owned
- Time: Away 8+ hours
- Special: Young kids, no other pets

**Expected Result:** Luna (cat) should score highest, Max (large dog) should score lowest

### Test Case 3: Experienced Owner
**Questionnaire Responses:**
- Housing: House with yard, 2000+ sq ft
- Activity: Moderate
- Experience: Previously owned, experienced training
- Time: 4-8 hours away
- Special: Adults only, no restrictions

**Expected Result:** Rocky (German Shepherd) should score well despite needing experience

## Troubleshooting

### Port Already in Use
```bash
# Change port in server.js line 5, or:
PORT=3001 npm start
```

### Dependencies Won't Install
```bash
# Clear cache and retry
rm -rf node_modules package-lock.json
npm install
```

### Page Won't Load
- Check console for errors
- Verify server is running (should see "🐾 PawfectMatch server running...")
- Try clearing browser cache

### Login Not Working
- Check you're using correct credentials
- Passwords are case-sensitive
- Try the test accounts listed above

## Data Persistence Note

⚠️ **Important:** This MVP uses in-memory storage. Data resets when you restart the server.

**What resets:**
- New user registrations
- Questionnaire responses
- Adoption requests
- Pet additions/edits (reverts to 6 originals)

**What doesn't reset:**
- The codebase
- Default test accounts
- Sample pets

To make data persistent, you need to integrate a database (MySQL/PostgreSQL). See README.md for migration instructions.

## Next Steps for Production

1. **Add Database**
   - Install MySQL: `npm install mysql2`
   - Create database schema
   - Replace global.pets, global.users with queries

2. **Deploy to Cloud**
   - Frontend/Backend: Render, Railway, Heroku
   - Database: PlanetScale, Supabase
   - Free tier available on all platforms

3. **Add Features**
   - Email notifications
   - Image uploads (not just URLs)
   - Advanced filtering
   - Analytics dashboard
   - SMS alerts via Africa's Talking

## Questions?

- Check `README.md` for full documentation
- Review code comments in `models/matching.js` for algorithm details
- Test accounts are in `config/seed-data.js`

## Demo Video Script (if needed)

1. Show homepage → "This is PawfectMatch"
2. Register new account → "Adopters create accounts"
3. Complete questionnaire → "12 questions, 2 minutes"
4. Show results → "Pets ranked by compatibility, detailed breakdowns"
5. Click top match → "Full pet profile with explanation"
6. Login as admin → "Shelter staff manage pets"
7. Show dashboard → "Statistics and insights"
8. Add new pet → "Easy pet management"

Total demo time: 3-4 minutes

---

**Project by:** Mariane Nyawira Kibicho (HDB212-2196/2022)
**Built with:** Node.js, Express, EJS, bcrypt
**Lines of Code:** ~2000
**Time to Set Up:** 5 minutes
