const bcrypt = require('bcrypt');

// Sample users
const samplePassword = bcrypt.hashSync('password123', 10);
const adminPassword = bcrypt.hashSync('admin123', 10);

global.users = [
  {
    id: 1,
    name: 'John Doe',
    email: 'user@example.com',
    password: samplePassword,
    role: 'adopter',
    createdAt: new Date()
  },
  {
    id: 2,
    name: 'Admin User',
    email: 'admin@example.com',
    password: adminPassword,
    role: 'admin',
    createdAt: new Date()
  }
];

// Sample pets
global.pets = [
  {
    id: 1,
    name: 'Max',
    species: 'Dog',
    breed: 'Labrador Retriever',
    age: 3,
    size: 'Large',
    energyLevel: 'High',
    temperament: 'Friendly, Active, Playful',
    trainingStatus: 'Basic commands',
    housingNeeds: 'House with yard preferred',
    experienceRequired: 'Beginner-friendly',
    timeRequirement: 'High - needs daily exercise',
    specialNeeds: 'None',
    goodWithKids: true,
    goodWithPets: true,
    description: 'Max is an energetic 3-year-old Labrador who loves playing fetch and going for long walks. He\'s great with children and other dogs.',
    image: 'https://images.unsplash.com/photo-1587300003388-59208cc962cb?w=400',
    available: true
  },
  {
    id: 2,
    name: 'Luna',
    species: 'Cat',
    breed: 'Domestic Shorthair',
    age: 2,
    size: 'Small',
    energyLevel: 'Low',
    temperament: 'Calm, Independent, Affectionate',
    trainingStatus: 'Litter trained',
    housingNeeds: 'Apartment suitable',
    experienceRequired: 'Beginner-friendly',
    timeRequirement: 'Low - independent',
    specialNeeds: 'Indoor only',
    goodWithKids: true,
    goodWithPets: false,
    description: 'Luna is a sweet, calm cat who loves quiet environments. She\'s perfect for someone looking for a low-maintenance companion.',
    image: 'https://images.unsplash.com/photo-1514888286974-6c03e2ca1dba?w=400',
    available: true
  },
  {
    id: 3,
    name: 'Rocky',
    species: 'Dog',
    breed: 'German Shepherd Mix',
    age: 5,
    size: 'Large',
    energyLevel: 'Moderate',
    temperament: 'Loyal, Protective, Intelligent',
    trainingStatus: 'Well-trained, knows commands',
    housingNeeds: 'House with secure yard required',
    experienceRequired: 'Some experience preferred',
    timeRequirement: 'Moderate - daily walks needed',
    specialNeeds: 'Needs experienced handler',
    goodWithKids: false,
    goodWithPets: false,
    description: 'Rocky is a loyal and intelligent dog who needs an experienced owner. He\'s best as the only pet in an adult household.',
    image: 'https://images.unsplash.com/photo-1568572933382-74d440642117?w=400',
    available: true
  },
  {
    id: 4,
    name: 'Bella',
    species: 'Dog',
    breed: 'Beagle',
    age: 4,
    size: 'Medium',
    energyLevel: 'Moderate',
    temperament: 'Friendly, Curious, Gentle',
    trainingStatus: 'Basic training',
    housingNeeds: 'Flexible - apartment or house',
    experienceRequired: 'Beginner-friendly',
    timeRequirement: 'Moderate - daily walks',
    specialNeeds: 'None',
    goodWithKids: true,
    goodWithPets: true,
    description: 'Bella is a gentle beagle who gets along with everyone. She loves food and sniffing around on walks!',
    image: 'https://images.unsplash.com/photo-1505628346881-b72b27e84530?w=400',
    available: true
  },
  {
    id: 5,
    name: 'Whiskers',
    species: 'Cat',
    breed: 'Siamese',
    age: 1,
    size: 'Small',
    energyLevel: 'High',
    temperament: 'Vocal, Playful, Social',
    trainingStatus: 'Litter trained',
    housingNeeds: 'Indoor with climbing spaces',
    experienceRequired: 'Some cat experience helpful',
    timeRequirement: 'Moderate - needs interaction',
    specialNeeds: 'Very vocal, needs attention',
    goodWithKids: true,
    goodWithPets: true,
    description: 'Whiskers is a young Siamese who loves to chat! He\'s very social and needs an owner who can give him attention.',
    image: 'https://images.unsplash.com/photo-1513245543132-31f507417b26?w=400',
    available: true
  },
  {
    id: 6,
    name: 'Charlie',
    species: 'Dog',
    breed: 'Poodle Mix',
    age: 7,
    size: 'Small',
    energyLevel: 'Low',
    temperament: 'Calm, Gentle, Senior',
    trainingStatus: 'Fully trained',
    housingNeeds: 'Any - prefers quiet',
    experienceRequired: 'Beginner-friendly',
    timeRequirement: 'Low - senior dog',
    specialNeeds: 'Senior care, gentle exercise',
    goodWithKids: false,
    goodWithPets: true,
    description: 'Charlie is a sweet senior dog looking for a quiet retirement home. He loves gentle walks and naps.',
    image: 'https://images.unsplash.com/photo-1534351590666-13e3e96b5017?w=400',
    available: true
  }
];

global.responses = [];
global.adoptionRequests = [];

console.log('✓ Sample data loaded: 2 users, 6 pets');
