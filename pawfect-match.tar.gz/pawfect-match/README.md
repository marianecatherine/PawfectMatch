# 🐾 PawfectMatch - Pet Adoption Compatibility System

**Final Year Project MVP**  
**Student:** Mariane Nyawira Kibicho (HDB212-2196/2022)  
**Supervisor:** Mr. Edward Kariuki

## Overview

PawfectMatch is a web-based pet adoption compatibility matching system that uses algorithmic assessment to match potential adopters with suitable pets based on lifestyle compatibility factors.

Unlike traditional adoption platforms that rely on appearance-based decisions, PawfectMatch evaluates 5 key compatibility dimensions:

1. **Housing Suitability** (30% weight) - Residence type, space, restrictions
2. **Activity Level** (25% weight) - Exercise commitment, energy matching
3. **Experience & Capability** (20% weight) - Previous ownership, training experience
4. **Time Availability** (15% weight) - Daily schedule, commitment capacity
5. **Special Considerations** (10% weight) - Household composition, other pets, special needs

## Features

### For Adopters
- ✅ Complete structured compatibility questionnaire (12 questions)
- ✅ Receive ranked pet recommendations with 0-100 compatibility scores
- ✅ View detailed score breakdowns across all 5 dimensions
- ✅ Browse all available pets
- ✅ Submit adoption interest requests
- ✅ Update responses to regenerate matches

### For Shelter Staff (Admin)
- ✅ Dashboard with system statistics
- ✅ Add, edit, and delete pet listings
- ✅ Manage pet profiles and behavioral assessments
- ✅ Review adoption requests
- ✅ Mark pets as adopted/unavailable

## Tech Stack

**Frontend:**
- HTML5, CSS3, JavaScript
- EJS templating engine
- Responsive design (mobile-friendly)

**Backend:**
- Node.js & Express.js
- Session-based authentication
- bcrypt for password hashing

**Data Storage:**
- In-memory storage (for MVP demonstration)
- Easy migration to MySQL/PostgreSQL for production

## Installation & Setup

### Prerequisites
- Node.js v18+ installed
- npm package manager

### Quick Start

```bash
# 1. Navigate to project directory
cd pawfect-match

# 2. Install dependencies
npm install

# 3. Start the server
npm start

# Server will run on http://localhost:3000
```

### Development Mode (with auto-reload)

```bash
npm run dev
```

## Test Accounts

The MVP comes with pre-loaded test accounts:

**Adopter Account:**
- Email: `user@example.com`
- Password: `password123`

**Admin Account:**
- Email: `admin@example.com`
- Password: `admin123`

## Sample Data

The system includes 6 sample pets with diverse characteristics:

1. **Max** - High-energy Labrador (Large, Active)
2. **Luna** - Calm Domestic Shorthair cat (Small, Low energy)
3. **Rocky** - German Shepherd Mix (Large, Needs experience)
4. **Bella** - Friendly Beagle (Medium, Beginner-friendly)
5. **Whiskers** - Vocal Siamese cat (Small, High energy)
6. **Charlie** - Senior Poodle Mix (Small, Low energy)

## How the Algorithm Works

### Compatibility Calculation

Each pet receives a score from 0-100 based on:

```
Total Score = (Housing × 0.30) + (Activity × 0.25) + 
              (Experience × 0.20) + (Time × 0.15) + 
              (Special × 0.10)
```

### Score Interpretation

- **90-100:** Excellent match (Highly recommended)
- **75-89:** Good match (Recommended)
- **60-74:** Fair match (Possible with awareness)
- **45-59:** Poor match (Not recommended)
- **0-44:** Incompatible

### Example Calculation

**Adopter Profile:**
- Lives in house with yard (1000 sq ft)
- Moderately active (daily walks)
- First-time owner
- Works 8 hours daily
- No other pets

**Pet: Bella the Beagle**
- Housing Score: 90/100 (house suitable for medium dog)
- Activity Score: 100/100 (moderate energy matches daily walks)
- Experience Score: 100/100 (beginner-friendly)
- Time Score: 85/100 (handles 8 hours alone)
- Special Score: 100/100 (no conflicts)

**Final Score:** (90×0.30) + (100×0.25) + (100×0.20) + (85×0.15) + (100×0.10) = **95/100**

**Interpretation:** Excellent match - highly recommended!

## Project Structure

```
pawfect-match/
├── config/
│   └── seed-data.js          # Sample users and pets
├── models/
│   └── matching.js           # Compatibility algorithm
├── routes/
│   ├── index.js              # Home, browse, pet details
│   ├── auth.js               # Login, register, logout
│   ├── questionnaire.js      # Questionnaire handling
│   ├── results.js            # Match results
│   └── admin.js              # Admin dashboard & management
├── views/
│   ├── index.ejs             # Home page
│   ├── login.ejs             # Login page
│   ├── register.ejs          # Registration
│   ├── questionnaire.ejs     # Compatibility quiz
│   ├── results.ejs           # Ranked matches
│   ├── browse.ejs            # Browse all pets
│   ├── pet-detail.ejs        # Individual pet profile
│   └── admin/
│       └── dashboard.ejs     # Admin dashboard
├── public/
│   └── css/
│       └── style.css         # All styles
├── server.js                 # Main application
└── package.json              # Dependencies

```

## User Workflows

### Adopter Workflow

1. **Register/Login** → Create account or sign in
2. **Complete Questionnaire** → Answer 12 questions about lifestyle
3. **View Results** → See ranked pets with compatibility scores
4. **Browse Details** → Click on pets to see full profiles
5. **Request Adoption** → Submit interest for top matches

### Admin Workflow

1. **Login** → Access admin dashboard
2. **View Statistics** → See total pets, users, pending requests
3. **Manage Pets** → Add new pets, edit existing profiles
4. **Review Requests** → Process adoption interest requests
5. **Update Availability** → Mark pets as adopted

## API Endpoints

### Public Routes
- `GET /` - Home page
- `GET /browse` - Browse all pets
- `GET /pet/:id` - View pet details
- `GET /auth/login` - Login page
- `POST /auth/login` - Process login
- `GET /auth/register` - Registration page
- `POST /auth/register` - Create account
- `GET /auth/logout` - Logout

### Adopter Routes (Authenticated)
- `GET /questionnaire` - Compatibility questionnaire
- `POST /questionnaire/submit` - Submit responses
- `GET /results` - View ranked matches
- `POST /adopt/:petId` - Submit adoption request

### Admin Routes (Admin Only)
- `GET /admin/dashboard` - Admin dashboard
- `GET /admin/pets` - Manage pets
- `POST /admin/pets/add` - Add new pet
- `POST /admin/pets/edit/:id` - Update pet
- `POST /admin/pets/delete/:id` - Delete pet
- `GET /admin/requests` - View adoption requests
- `POST /admin/requests/:id/status` - Update request status

## Limitations (MVP)

1. **In-Memory Storage** - Data resets on server restart (use database for production)
2. **No Image Uploads** - Uses image URLs only
3. **Basic Authentication** - No password reset or email verification
4. **No Real-time Updates** - Requires page refresh
5. **Single Shelter** - Designed for one organization
6. **No Payment Processing** - Adoption fees handled externally

## Future Enhancements

- [ ] MySQL/PostgreSQL database integration
- [ ] Image upload functionality
- [ ] Email notifications for adoption requests
- [ ] SMS alerts via Africa's Talking API
- [ ] Advanced search and filtering
- [ ] Adoption success tracking
- [ ] Algorithm weight adjustment based on outcomes
- [ ] Multi-shelter support
- [ ] Mobile app (React Native)
- [ ] Machine learning for improved matching

## Production Deployment

### Database Migration

Replace in-memory storage with MySQL:

```javascript
// Install mysql2
npm install mysql2

// Update models to use database queries
const mysql = require('mysql2/promise');

const pool = mysql.createPool({
  host: process.env.DB_HOST,
  user: process.env.DB_USER,
  password: process.env.DB_PASSWORD,
  database: process.env.DB_NAME
});
```

### Environment Variables

Create `.env` file:

```
PORT=3000
SESSION_SECRET=your-secret-key-here
DB_HOST=localhost
DB_USER=root
DB_PASSWORD=your-password
DB_NAME=pawfect_match
```

### Cloud Hosting Options

- **Frontend & Backend:** Render, Railway, Heroku
- **Database:** PlanetScale (MySQL), Supabase (PostgreSQL)
- **Static Files:** Cloudflare R2, AWS S3

## Validation Results

*To be completed with user testing data*

**Target Metrics:**
- 75% algorithm agreement with domain experts
- 80% user satisfaction rating
- Reduced decision time for adopters
- Improved match quality vs. random selection

## License

This project is part of an academic final year project submission.

## Contact

**Student:** Mariane Nyawira Kibicho  
**Registration:** HDB212-2196/2022  
**Email:** [Your email]  
**Supervisor:** Mr. Edward Kariuki

---

*Built with ❤️ for better pet adoption outcomes*
