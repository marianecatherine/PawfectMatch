// Compatibility Matching Algorithm
// Calculates a 0-100 compatibility score based on 5 dimensions

const WEIGHTS = {
  housing: 0.30,      // 30%
  activity: 0.25,     // 25%
  experience: 0.20,   // 20%
  time: 0.15,         // 15%
  special: 0.10       // 10%
};

function calculateCompatibility(responses, pet) {
  const scores = {
    housing: calculateHousingScore(responses, pet),
    activity: calculateActivityScore(responses, pet),
    experience: calculateExperienceScore(responses, pet),
    time: calculateTimeScore(responses, pet),
    special: calculateSpecialScore(responses, pet)
  };

  const totalScore = 
    scores.housing * WEIGHTS.housing +
    scores.activity * WEIGHTS.activity +
    scores.experience * WEIGHTS.experience +
    scores.time * WEIGHTS.time +
    scores.special * WEIGHTS.special;

  return {
    totalScore: Math.round(totalScore),
    breakdown: scores
  };
}

function calculateHousingScore(responses, pet) {
  let score = 100;

  // Residence type matching
  const residenceType = responses.residenceType;
  const petSize = pet.size;

  if (residenceType === 'apartment' && petSize === 'Large') {
    score -= 30;
  } else if (residenceType === 'apartment' && petSize === 'Medium') {
    score -= 10;
  }

  if (pet.housingNeeds.includes('yard') && !residenceType.includes('yard')) {
    score -= 25;
  }

  // Space size matching
  const space = responses.livingSpace;
  if (space === 'under500' && petSize !== 'Small') {
    score -= 30;
  } else if (space === '500-1000' && petSize === 'Large') {
    score -= 20;
  }

  // Restrictions
  if (responses.restrictions !== 'none') {
    score -= 15;
  }

  return Math.max(0, Math.min(100, score));
}

function calculateActivityScore(responses, pet) {
  const activityMap = {
    sedentary: 1,
    light: 2,
    moderate: 3,
    active: 4
  };

  const energyMap = {
    Low: 1,
    Moderate: 3,
    High: 4
  };

  const userActivity = activityMap[responses.activityLevel] || 2;
  const petEnergy = energyMap[pet.energyLevel] || 2;

  const difference = Math.abs(userActivity - petEnergy);

  if (difference === 0) return 100;
  if (difference === 1) return 85;
  if (difference === 2) return 60;
  return 30;
}

function calculateExperienceScore(responses, pet) {
  const experienceLevel = responses.previousPets;
  const petRequirement = pet.experienceRequired;

  if (petRequirement.includes('Beginner')) {
    return 100; // Any experience level works
  }

  if (petRequirement.includes('experience') || petRequirement.includes('experienced')) {
    if (experienceLevel === 'never') return 40;
    if (experienceLevel === 'child') return 60;
    if (experienceLevel === 'adult') return 90;
    if (experienceLevel === 'current') return 100;
  }

  return 85;
}

function calculateTimeScore(responses, pet) {
  const timeAway = responses.timeAway;
  const petTimeReq = pet.timeRequirement;

  let score = 100;

  if (petTimeReq.includes('High') || petTimeReq.includes('daily exercise')) {
    if (timeAway === 'more8') score = 40;
    else if (timeAway === '4-8') score = 70;
    else if (timeAway === 'less4') score = 90;
    else score = 100; // work from home
  } else if (petTimeReq.includes('Low') || petTimeReq.includes('independent')) {
    if (timeAway === 'more8') score = 90;
    else score = 100;
  } else { // Moderate
    if (timeAway === 'more8') score = 60;
    else if (timeAway === '4-8') score = 85;
    else score = 100;
  }

  return score;
}

function calculateSpecialScore(responses, pet) {
  let score = 100;

  // Kids compatibility
  if (responses.household.includes('youngKids')) {
    if (!pet.goodWithKids) score -= 40;
  }

  // Other pets compatibility
  if (responses.otherPets !== 'none') {
    if (!pet.goodWithPets) score -= 35;
  }

  // Special needs willingness
  if (pet.specialNeeds !== 'None' && responses.specialNeedsWilling === 'healthy') {
    score -= 30;
  }

  return Math.max(0, Math.min(100, score));
}

function getScoreInterpretation(score) {
  if (score >= 90) return { level: 'Excellent', color: '#10b981', message: 'Highly recommended match!' };
  if (score >= 75) return { level: 'Good', color: '#3b82f6', message: 'Recommended match' };
  if (score >= 60) return { level: 'Fair', color: '#f59e0b', message: 'Possible with awareness' };
  if (score >= 45) return { level: 'Poor', color: '#ef4444', message: 'Not recommended' };
  return { level: 'Incompatible', color: '#991b1b', message: 'Incompatible' };
}

function getRankedMatches(responses) {
  const matches = global.pets
    .filter(pet => pet.available)
    .map(pet => {
      const compatibility = calculateCompatibility(responses, pet);
      return {
        pet,
        ...compatibility,
        interpretation: getScoreInterpretation(compatibility.totalScore)
      };
    })
    .sort((a, b) => b.totalScore - a.totalScore);

  return matches;
}

module.exports = {
  calculateCompatibility,
  getRankedMatches,
  getScoreInterpretation
};
