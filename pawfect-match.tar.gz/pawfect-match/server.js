const express = require('express');
const session = require('express-session');
const bodyParser = require('body-parser');
const path = require('path');
require('dotenv').config();

const app = express();
const PORT = process.env.PORT || 3000;

// Middleware
app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'views'));
app.use(express.static(path.join(__dirname, 'public')));
app.use(bodyParser.urlencoded({ extended: true }));
app.use(bodyParser.json());
app.use(session({
  secret: process.env.SESSION_SECRET || 'pawfect-match-secret-key',
  resave: false,
  saveUninitialized: false,
  cookie: { maxAge: 24 * 60 * 60 * 1000 } // 24 hours
}));

// In-memory data stores (replace with database in production)
global.users = [];
global.pets = [];
global.responses = [];
global.adoptionRequests = [];

// Initialize sample data
require('./config/seed-data');

// Routes
const indexRoutes = require('./routes/index');
const authRoutes = require('./routes/auth');
const questionnaireRoutes = require('./routes/questionnaire');
const resultsRoutes = require('./routes/results');
const adminRoutes = require('./routes/admin');

app.use('/', indexRoutes);
app.use('/auth', authRoutes);
app.use('/questionnaire', questionnaireRoutes);
app.use('/results', resultsRoutes);
app.use('/admin', adminRoutes);

// Start server
app.listen(PORT, () => {
  console.log(`🐾 PawfectMatch server running on http://localhost:${PORT}`);
  console.log(`
  ====================================
  Welcome to PawfectMatch MVP!
  ====================================
  
  Test Accounts:
  - Adopter: user@example.com / password123
  - Admin: admin@example.com / admin123
  
  Features:
  ✓ Compatibility questionnaire
  ✓ Algorithmic pet matching
  ✓ Ranked recommendations
  ✓ Admin dashboard
  ✓ Pet management
  ====================================
  `);
});
